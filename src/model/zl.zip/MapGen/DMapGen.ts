export {}

export const GT_PATH = 32;

export namespace MAP_GEN_ENUM {

    export enum DMAP_FUNC
    {
        LINEAR = 0,
        LESS_IS_LIKLY,
        MORE_IS_LIKLY
    }

    export enum PLACEMENT
    {
        RANDOM = 0,
        CLUSTER,
        PLANET_RING,
        STREEKS,
        SPOTS,
    }

    export enum OVERLAP
    {
        NO_OVERLAP = 0,
        LEVEL1,//can overlap another LEVEL1 or LEVEL2
        LEVEL2//may be overlaped by a level1
    }

    export enum SECTOR_SIZE
    {
        SMALL_SIZE = 0x01,
        MEDIUM_SIZE = 0x02,
        LARGE_SIZE = 0x04,
        S_M_SIZE = 0x03,
        S_L_SIZE = 0x05,
        M_L_SIZE = 0x06,
        ALL_SIZE = 0x07
    }

    export enum SECTOR_FORMATION
    {
        SF_RANDOM,
        SF_RING,
        SF_DOUBLERING,
        SF_STAR,
        SF_INRING,
        SF_MULTI_RANDOM
    }

    export enum MACRO_OPERATION
    {
        MC_PLACE_HABITABLE_PLANET,
        MC_PLACE_GAS_PLANET,
        MC_PLACE_METAL_PLANET,
        MC_PLACE_OTHER_PLANET,
        MC_PLACE_TERRAIN,
        MC_PLACE_PLAYER_BOMB,
        MC_MARK_RING
    }
}


const MAX_TERRAIN = 20;
const MAX_THEMES = 30;
const MAX_TYPES = 6;
const MAX_MACROS = 15;

export class TerrainInfo {
    terrainArchType: number[] = Array(GT_PATH)
    probability: number;
    minToPlace: number;
    maxToPlace: number;
    numberFunc: MAP_GEN_ENUM.DMAP_FUNC;
    size: number;
    requiredToPlace: number;
    overlap: MAP_GEN_ENUM.OVERLAP;
    placement: MAP_GEN_ENUM.PLACEMENT;
}

export class Macros {
    operation: MAP_GEN_ENUM.MACRO_OPERATION;
    range: number;
    active: boolean;
    info: TerrainInfo | MAP_GEN_ENUM.OVERLAP;
}

export class TerrainTheme {
    systemKit: string[][] = Array(MAX_TYPES).fill(Array(GT_PATH))
    metalPlanets: string[][] = Array(MAX_TYPES).fill(Array(GT_PATH))
    gasPlanets: string[][] = Array(MAX_TYPES).fill(Array(GT_PATH))
    habitablePlanets: string[][] = Array(MAX_TYPES).fill(Array(GT_PATH))
    otherPlanets: string[][] = Array(MAX_TYPES).fill(Array(GT_PATH))

    moonTypes: string[][] = Array(MAX_TYPES).fill(Array(GT_PATH))

    sizeOk: MAP_GEN_ENUM.SECTOR_SIZE;
    minSize: number;
    maxSize: number;
    sizeFunc: MAP_GEN_ENUM.DMAP_FUNC

    numHabitablePlanets: number[] = Array(3);
    numMetalPlanets: number[] = Array(3);
    numGasPlanets: number[] = Array(3);
    numOtherPlanets: number[] = Array(3);

    minMoonsPerPlanet: number;
    maxMoonsPerPlanet: number;
    moonNumberFunc: MAP_GEN_ENUM.DMAP_FUNC;

    numNuggetPatchesMetal: number[] = Array(3);
    numNuggetPatchesGas: number[] = Array(3);

    terrain: TerrainInfo[] = Array(MAX_TERRAIN);
    nuggetsMetalTypes: TerrainInfo[] = Array(MAX_TYPES)
    nuggetsGasTypes: TerrainInfo[] = Array(MAX_TYPES)

    okForPlayerStart: boolean = true;
    okForRemoteSystem: boolean = true;

    density: number[] = Array(3);

    macos: number[] = Array(MAX_MACROS);

}

export class BT_MAP_GEN {

    themes: TerrainTheme[] = Array(MAX_THEMES).fill(new TerrainTheme());

}
