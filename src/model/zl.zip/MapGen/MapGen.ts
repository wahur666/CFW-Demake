import {BT_MAP_GEN, GT_PATH, MAP_GEN_ENUM, TerrainInfo, TerrainTheme} from "./DMapGen";
import {IMapGen} from "./IMapGen";
import {FullCQGame} from "../Base/CQGame";
import {IPAnim} from "../Base/InProgressAnim";
import Vector3 = Phaser.Math.Vector3;
import {CQGAMETYPES} from "../Base/DCQGame";
import TERRAIN = CQGAMETYPES.TERRAIN;

export {}

const MAX_PLAYERS = 8
const MAX_SYSTEMS = 16;
const GRID_SIZE = 4096;
const PLANET_SIZE = GRID_SIZE * 2.0;
const MAX_MAP_GRID = 64;
const MAX_MAP_SIZE = MAX_MAP_GRID * GRID_SIZE;

const RND_MAX_PLAYER_SYSTEMS = 8; // length constraint
const rndPlayerX: number[] = [0, 2, 5, 8, 9, 7, 4, 1];
const rndPlayerY: number[] = [4, 1, 0, 2, 5, 8, 9, 7];


const RND_MAX_REMOTE_SYSTEMS = 20;
const rndRemoteX: number[] = [4, 6, 1, 3, 5, 7, 2, 4, 6, 8, 1, 3, 5, 7, 2, 4, 6, 8, 3, 5];
const rndRemoteY: number[] = [2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7];

const RING_MAX_SYSTEMS = 16;
const ringSystemX: number[] = [5, 6, 8, 7, 9, 7, 7, 5, 4, 3, 1, 2, 0, 2, 2, 4];
const ringSystemY: number[] = [0, 2, 2, 4, 5, 6, 8, 7, 9, 7, 7, 5, 4, 3, 1, 2];

const STAR_MAX_TREE = 8;
const starCenterX = 4;
const starCenterY = 4;
const starTreeX: number[][] = [[4, 3, 5], [6, 7, 8], [6, 8, 8], [6, 8, 7], [4, 5, 3], [2, 1, 0], [2, 0, 0], [2, 0, 1]];
const starTreeY: number[][] = [[2, 0, 0], [2, 0, 1], [4, 3, 5], [6, 7, 8], [6, 8, 8], [6, 8, 7], [4, 5, 3], [2, 1, 0]];

const FIX15 = 15;

const INT_MAX = Math.pow(2, 32) - 1;

const MAX_TERRAIN = 20;
const MAX_THEMES = 30;
const MAX_TYPES = 6;
const MAX_MACROS = 15;

function linerFunc(): number {
    return Math.round(Math.random() * INT_MAX);
}

function lessIsLikelyFunc(): number {
    let v = linerFunc();
    v = v * v >> FIX15;
    v = v * v >> FIX15;
    return v;
}

function moreIsLikelyFunc(): number {
    let v = linerFunc();
    v = v * v >> FIX15;
    v = v * v >> FIX15;
    return 0x00007FFF - v;
}

const randFunc: (() => number)[] = [linerFunc, lessIsLikelyFunc, moreIsLikelyFunc]

const GENMAP_TAKEN = 1;
const GENMAP_LEVEL1 = 2;
const GENMAP_LEVEL2 = 3;
const GENMAP_PATH = 4;

const FLAG_PLANET = 0x01;
const FLAG_PATHON = 0x02;

const MAX_FLAGS = 20;

class FlagPost {
    type: number; //u8
    xPos: number; //u8
    yPos: number; //u8
}

class GenSystem {
    flags: FlagPost[] = Array(MAX_FLAGS);
    numFlags: number;

    sectorGridX: number;
    sectorGridY: number;
    index: number;

    planetNameCount: number;

    x: number;
    y: number;
    size: number;
    jumpgateCount: number;
    distToSystem: number[] = Array(MAX_SYSTEMS);
    jumpgates: GenJumpgate[] = Array(MAX_SYSTEMS);
    systemId: number;
    playerId: number;
    connectionOrder: number;
    playerDistToSystem: number[][] = Array(MAX_PLAYERS).fill(Array(MAX_SYSTEMS));
    theme: TerrainTheme;

    omStartEmpty: number;
    omUsed: number;
    objectMap: number[][] = Array(MAX_MAP_GRID).fill(Array(MAX_MAP_GRID));

    initObjectMap() {
        this.omUsed = 0;
        this.omStartEmpty = 0;
        const centerDist = this.size / 2;
        const centerBoarder = centerDist - 1;
        const centerBoarder2 = centerBoarder * centerBoarder;
        const centerDist2 = centerDist * centerDist;
        for (let i = 0; i < this.size; i++) {
            for (let j = 0; j < this.size; j++) {
                const dist = (i - centerDist) * (i - centerDist) + (j - centerDist) * (j - centerDist);
                if (dist > centerDist2) {
                    this.objectMap[i][j] = GENMAP_TAKEN;
                } else if (dist >= centerBoarder2) {
                    this.objectMap[i][j] = GENMAP_LEVEL1
                } else {
                    this.omStartEmpty += 1;
                    this.objectMap[i][j] = 0;
                }
            }
        }
    }
}


class GenJumpgate {
    system1: GenSystem;
    system2: GenSystem;
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    dist: number;
    created: boolean = true;
}

class GenStruct {
    data: BT_MAP_GEN;

    numPlayers: number;

    sectorSize: number;
    sectorGrid: number[] = Array(17);

    gameSize: number;
    sectorLayout: MAP_GEN_ENUM.SECTOR_FORMATION;

    systemsToMake: number;

    terrainSize: number;

    objectBoarder: number;
    system: GenSystem[] = Array(MAX_SYSTEMS);
    systemCount: number;

    jumpgate: GenJumpgate[] = Array(MAX_SYSTEMS / MAX_SYSTEMS)
    numJumpGates: number;
}

function validData(data: BT_MAP_GEN): boolean {
    let numThemes: number = 0;
    while((data.themes[numThemes].okForRemoteSystem || data.themes[numThemes].okForPlayerStart) && numThemes < MAX_THEMES)
    {
        ++numThemes;
    }
    // CQASSERT(numThemes && "You don't have any themes with okForRemoteSystem or okForPlayerStart");

    if(numThemes)
    {
        let bHasHomeSystem = false;
        let bHasRemoteSystem = false;
        for(let i = 0; i < numThemes; ++i)
        {
            if(data.themes[i].okForRemoteSystem)
                bHasRemoteSystem = true;
            if(data.themes[i].okForPlayerStart)
                bHasHomeSystem = true;

            let numHabitable = 0;
            let numMetalPL = 0;
            let numGasPL = 0;
            let numCrew = 0;

            let count: number;
            for(count = 0; count < MAX_TYPES; ++count)
            {
                if(data.themes[i].habitablePlanets[count][0])
                {
                    ++numHabitable;
                    if(!(ARCHLIST->GetArchetypeData(data.themes[i].habitablePlanets[count])))
                    {
                        CQBOMB3("Bad MapGenData - Theme:%d habitablePlanets:%d String:%s",i,count,data.themes[i].habitablePlanets[count]);
                        return true;
                    }
                }
                else
                    break;
            }

            for(count = 0; count < MAX_TYPES; ++count)
            {
                if(data.themes[i].metalPlanets[count][0])
                {
                    ++numMetalPL;
                    if(!(ARCHLIST->GetArchetypeData(data->themes[i].metalPlanets[count])))
                    {
                        CQBOMB3("Bad MapGenData - Theme:%d metalPlanets:%d String:%s",i,count,data->themes[i].metalPlanets[count]);
                        return true;
                    }
                }
                else
                    break;
            }

            for(count = 0; count < MAX_TYPES; ++count)
            {
                if(data->themes[i].gasPlanets[count][0])
                {
                    ++numGasPL;
                    if(!(ARCHLIST->GetArchetypeData(data->themes[i].gasPlanets[count])))
                    {
                        CQBOMB3("Bad MapGenData - Theme:%d gasPlanets:%d String:%s",i,count,data->themes[i].gasPlanets[count]);
                        return true;
                    }
                }
                else
                    break;
            }

            for(count = 0; count < MAX_TYPES; ++count)
            {
                if(data->themes[i].otherPlanets[count][0])
                {
                    ++numCrew;
                    if(!(ARCHLIST->GetArchetypeData(data->themes[i].otherPlanets[count])))
                    {
                        CQBOMB3("Bad MapGenData - Theme:%d otherPlanets:%d String:%s",i,count,data->themes[i].otherPlanets[count]);
                        return true;
                    }
                }
                else
                    break;
            }

            if((!numHabitable) && (data->themes[i].numHabitablePlanets[0] || data->themes[i].numHabitablePlanets[1]|| data->themes[i].numHabitablePlanets[2]))
            {
                CQBOMB1("Bad MapGenData - Theme:%d  Has no habitable planets but tries to place them",i);
            }
            if((!numMetalPL) && (data->themes[i].numMetalPlanets[0] || data->themes[i].numMetalPlanets[1]|| data->themes[i].numMetalPlanets[2]))
            {
                CQBOMB1("Bad MapGenData - Theme:%d  Has no metal planets but tries to place them",i);
            }
            if((!numGasPL) && (data->themes[i].numGasPlanets[0] || data->themes[i].numGasPlanets[1]|| data->themes[i].numGasPlanets[2]))
            {
                CQBOMB1("Bad MapGenData - Theme:%d  Has no gas planets but tries to place them",i);
            }
            if((!numCrew) && (data->themes[i].numOtherPlanets[0] || data->themes[i].numOtherPlanets[1]|| data->themes[i].numOtherPlanets[2]))
            {
                CQBOMB1("Bad MapGenData - Theme:%d  Has no other planets but tries to place them",i);
            }
        }
        CQASSERT(bHasHomeSystem && "You need at least one theme marked as okForPlayerStart");
        CQASSERT(bHasRemoteSystem && "You need at least one theme marked as okForRemoteSystem");
    }
    return true;
}

class MapGen implements IMapGen {

    /* IMapGen methods */
    GenerateMap(game: FullCQGame) {
        const map: GenStruct = new GenStruct();
        this.initMap(map, game);
        this.GenerateSystems(map);
        this.SelectThemes(map);
        this.CreateSystems(map);
        this.RunHomeMacros(map);
        this.CreateJumpgates(map);
        this.PopulateSystems(map);
    }

    GetBestSystemNumber(game: FullCQGame, approxNumber: number): number {
        return 0;
    }

    GetPossibleSystemNumbers(game: FullCQGame, list: number[]): number {
        return 0;
    }

    //map gen stuff
    initMap(map: GenStruct, game: FullCQGame) {
        const data = new BT_MAP_GEN();

    }

    insertObject(object: string, position: Vector3, playerID: number, systemID: number, system: GenSystem) {
    }

    //Util funcs

    GetRand(min: number, max: number, mapFunc: MAP_GEN_ENUM.DMAP_FUNC): number {
        return 0;
    }

    GenerateSystems(map: GenStruct) {
    }

    generateSystemsRandom(map: GenStruct) {

    };

    generateSystemsRing(map: GenStruct) {

    };

    generateSystemsStar(map: GenStruct) {

    };

    SystemsOverlap(map: GenStruct, system: GenSystem): boolean {
        return false;
    }

    GetJumpgatePositions(map: GenStruct, sys1: GenSystem, sys2: GenSystem): { jx1: number, jy1: number, jx2: number, jy2: number } {
        return {jx1: 0, jy1: 0, jx2: 0, jy2: 0}
    }

    CrossesAnotherSystem(map: GenStruct, sys1: GenSystem, sys2: GenSystem, jx1: number, jy1: number, jx2: number, jy2: number): boolean {
        return false;
    }

    CrossesAnotherLink(map: GenStruct, gate: GenJumpgate): boolean {
        return false;
    }

    LinesCross(line1x1: number, line1y1: number, line1x2: number, line1y2: number, line2x1: number, line2y1: number, line2x2: number, line2y2: number): boolean {
        return false;
    }

    SelectThemes(map: GenStruct) {

    }

    CreateSystems(map: GenStruct) {

    }

    RunHomeMacros(map: GenStruct) {

    }

    findMacroPosition(system: GenSystem, centerX: number, centerY: number, range: number, size: number, overlap: MAP_GEN_ENUM.OVERLAP): { result: boolean, posX?: number, posY?: number } {
        return {result: false, posX: 0, posY: 0}
    }

    getMacroCenterPos(system: GenSystem): { x: number, y: number } {
        return {x: 0, y: 0}
    }

    createPlanetFromList(xPos: number, yPos: number, system: GenSystem, range: number, planetList: string[] = new Array(GT_PATH)) {

    }

    placeMacroTerrain(centerX: number, centerY: number, system: GenSystem, range: number, terrainInfo: TerrainInfo) {

    }

    CreateJumpgates(map: GenStruct) {

    }

    createRandomGates3(map: GenStruct) {

    }

    createGateLevel2(map: GenStruct, totalLevel: number, levelSystems: number, targetSystems: number, gateNum: number, currentGates: number[], score: number,
                     bestGates: number[], bestScore: number, bestGateNum: number, moreAllowed: boolean): { bestScore: number, bestGateNum: number } {
        return {bestScore: 0, bestGateNum: 0}
    }

    createRandomGates2(map: GenStruct) {

    }

    createGateLevel(map: GenStruct, totalLevel: number, levelSystems: number, targetSystems: number, gateNum: number, currentGates: number[], score: number,
                    bestGates: number[], bestScore: number, bestGateNum: number, moreAllowed: boolean): { bestScore: number, bestGateNum: number } {
        return {bestScore: 0, bestGateNum: 0}
    }


    scoreGate(map: GenStruct, gateIndex: number): number {
        return 0;
    }

    markSystems(systemUnconnected: number, system: GenSystem, systemsVisited: number): { systemUnconnected: number, systemsVisited: number } {
        return {systemsVisited: 0, systemUnconnected: 0}
    }

    createRandomGates(map: GenStruct) {
    }

    createRingGates(map: GenStruct) {
    }

    createStarGates(map: GenStruct) {
    }

    createJumpgatesForIndexs(map: GenStruct, index1: number, index2: number) {

    }

    PopulateSystems(map: GenStruct, ipAnim?: IPAnim) {

    }

    PopulateSystem(map: GenStruct, system: GenSystem) {

    }

    placePlanetsMoons(map: GenStruct, system: GenSystem, planetPosX: number, planetPosY: number) {

    }

    SpaceEmpty(system: GenSystem, xPos: number, yPos: number, overlap: MAP_GEN_ENUM.OVERLAP, size: number): boolean {
        return false;
    }

    FillPosition(system: GenSystem, xPos: number, yPos: number, size: number, overlap: MAP_GEN_ENUM.OVERLAP) {

    }

    FindPosition(system: GenSystem, width: number, overlap: MAP_GEN_ENUM.OVERLAP): { xPos: number, yPos: number, res: boolean } {
        return {res: true, xPos: 0, yPos: 0}
    }

//	bool ColisionWithObject(GenObj * obj,Vector vect,U32 rad,MAP_GEN_ENUM::OVERLAP overlap);

    GenerateTerain(map: GenStruct, system: GenSystem) {

    }

    PlaceTerrain(map: GenStruct, terrain: TerrainInfo, system: GenSystem) {

    }

    PlaceRandomField(terrain: TerrainInfo, numToPlace: number, startX: number, startY: number, system: GenSystem) {

    }

    PlaceSpottyField(terrain: TERRAIN, numToPlace: number, startX: number, startY: number, system: GenSystem) {

    }

    PlaceRingField(terrain: TerrainInfo, system: GenSystem) {

    }

    PlaceRandomRibbon(terrain: TerrainInfo, length: number, startX: number, startY: number, system: GenSystem) {

    }

    BuildPaths(system: GenSystem) {

    }

    //other
    init() {
    }


    removeFromArray(nx: number, ny: number, tempX: number[], tempY: number[], tempIndex: number): number {
        return tempIndex;
    }

    isInArray(arrX: number[], arrY: number[], index: number, nx: number, ny: number): boolean {
        return false;
    }

    // isOverlapping(arrX: number[], arrY: number[], index: number, nx: number, ny: number): boolean {
    //     return false;
    // }

    checkNewXY(tempX: number[], tempY: number[], tempIndex: number, finalX: number, finalY: number, finalIndex: number, terrain: TerrainInfo,
               system: GenSystem, newX: number, newY: number): number {
        return tempIndex;
    }

    connectPosts(post1: FlagPost, post2: FlagPost, system: GenSystem) {

    }

}
