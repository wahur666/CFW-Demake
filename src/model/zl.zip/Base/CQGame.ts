import {CQGame} from "./DCQGame";


export class FullCQGame extends CQGame {

}
